# LEVEL - 1 - TASK - 1

string=input("Enter a String:")
rev=string[::-1]
print("The reverse of the given string is:",rev)
