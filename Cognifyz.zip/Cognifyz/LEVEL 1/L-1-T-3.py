# LEVEL - 1 

# TASK - 3

email=input("Enter your email id:")
if "@" in email and "." in email:
    print("Valid Email Address.")
else:
    print("Invalid Email Address.")

